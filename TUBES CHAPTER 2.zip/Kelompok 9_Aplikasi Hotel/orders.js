const Orders = [
    {
        productName: 'Foldable Mini Drone',
        productNumber: '85631',
        paymentStatus: 'Due',
        shipping: 'Pending'
    },
    {
        productName: 'Lavendar KF1110 Drone',
        productNumber: '177013',
        paymentStatus: 'Refuned',
        shipping: 'Declined'
    },
    {
        productName: 'Yokoda Keichi 531 Drone',
        productNumber: '21187',
        paymentStatus: 'Paid',
        shipping: 'Delivered'
    },
    {
        productName: 'Nikuna CamPro Drone',
        productNumber: '36587',
        paymentStatus: 'Due',
        shipping: 'Pending'
    },
    {
        productName: 'Century 4K Drone',
        productNumber: '81270',
        paymentStatus: 'Paid',
        shipping: 'Delivered'
    },
    {
        productName: 'Yokoda Alcatraz Drone',
        productNumber: '13779',
        paymentStatus: 'Refuned',
        shipping: 'Declined'

    },
    {
        productName: 'Yokoda Keichi 531 Drone',
        productNumber: '21187',
        paymentStatus: 'Due',
        shipping: 'Pending'
        
    },
]